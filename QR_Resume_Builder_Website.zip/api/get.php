<?php
require_once __DIR__ . '/db.php';
$token = preg_replace('/[^a-f0-9]/','', $_GET['token'] ?? '');
if (strlen($token) !== 32) json_out(['ok'=>false,'error'=>'Invalid token'],400);
$stmt = db()->prepare("SELECT id,token,status,data,photo,created_at,updated_at FROM resumes WHERE token=?");
$stmt->execute([$token]);
$row = $stmt->fetch();
if (!$row) json_out(['ok'=>false,'error'=>'Resume session not found'],404);
$data = json_decode($row['data'] ?: '{}', true);
json_out(['ok'=>true,'resume'=>[
    'id'=>$row['id'],'token'=>$row['token'],'status'=>$row['status'],
    'data'=>$data,'photo'=>$row['photo'],'created_at'=>$row['created_at'],'updated_at'=>$row['updated_at']
]]);
?>
