<?php
require_once __DIR__ . '/db.php';
try {
    $token = bin2hex(random_bytes(16));
    $stmt = db()->prepare("INSERT INTO resumes (token,status,data) VALUES (?, 'waiting', ?)");
    $stmt->execute([$token, json_encode(new stdClass())]);
    json_out(['ok'=>true, 'token'=>$token]);
} catch (Throwable $e) {
    json_out(['ok'=>false,'error'=>'Database error. Check config.php and database setup.'],500);
}
?>
