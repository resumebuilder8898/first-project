<?php
require_once __DIR__ . '/db.php';
$body = body_json();
$token = preg_replace('/[^a-f0-9]/','', $body['token'] ?? '');
$data = $body['data'] ?? [];
$photo = $body['photo'] ?? null;

if (strlen($token) !== 32 || !is_array($data)) json_out(['ok'=>false,'error'=>'Invalid submission'],400);

$stmt = db()->prepare("SELECT id,status,created_at FROM resumes WHERE token=?");
$stmt->execute([$token]);
$row = $stmt->fetch();
if (!$row) json_out(['ok'=>false,'error'=>'Session not found'],404);

$created = strtotime($row['created_at']);
if (time() - $created > SESSION_MINUTES*60) json_out(['ok'=>false,'error'=>'This QR session has expired. Please ask the PC operator for a new QR code.'],410);

$allowed = ['name','jobTitle','phone','email','address','objective','education','experience','skills','projects','certifications','languages'];
$clean = [];
foreach ($allowed as $k) {
    if (isset($data[$k])) $clean[$k] = $data[$k];
}
if (trim($clean['name'] ?? '') === '') json_out(['ok'=>false,'error'=>'Name is required'],422);

if ($photo && strlen($photo) > 4*1024*1024) json_out(['ok'=>false,'error'=>'Photo is too large'],422);

$stmt = db()->prepare("UPDATE resumes SET status='submitted', data=?, photo=? WHERE token=?");
$stmt->execute([json_encode($clean, JSON_UNESCAPED_UNICODE), $photo, $token]);
json_out(['ok'=>true]);
?>
