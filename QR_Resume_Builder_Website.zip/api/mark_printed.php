<?php
require_once __DIR__ . '/db.php';
$body = body_json();
$token = preg_replace('/[^a-f0-9]/','', $body['token'] ?? '');
if (strlen($token) !== 32) json_out(['ok'=>false,'error'=>'Invalid token'],400);
$stmt = db()->prepare("UPDATE resumes SET status='printed' WHERE token=?");
$stmt->execute([$token]);
json_out(['ok'=>true]);
?>
