<?php require_once __DIR__.'/config.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars(APP_NAME) ?> — PC Dashboard</title>
<link rel="stylesheet" href="assets/style.css">
<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
</head>
<body>
<div class="topbar"><div><b>QR Resume Builder</b><span class="muted">PC / Admin Dashboard</span></div><button class="btn primary" id="newBtn">＋ New Resume</button></div>
<main class="dashboard">
<section class="card qr-card">
<h2>Scan to Fill Resume</h2>
<p class="muted">Create a session, then scan the QR code using the customer's phone.</p>
<div id="qr" class="qrbox"><div class="qr-placeholder">Click “New Resume”</div></div>
<div id="sessionUrl" class="session-url"></div>
<div class="status-pill" id="status">No active session</div>
<button class="btn" id="copyBtn" disabled>Copy Link</button>
</section>

<section class="card preview-card">
<div class="preview-head"><div><h2>Resume Preview</h2><span id="received" class="muted">Waiting for submission…</span></div><div class="actions"><button class="btn" id="printBtn" disabled>🖨 Print</button><button class="btn danger" id="clearBtn">Clear</button></div></div>
<div id="resume" class="paper"><div class="empty">Your submitted resume will appear here.</div></div>
</section>
</main>
<script src="assets/admin.js"></script>
</body></html>
