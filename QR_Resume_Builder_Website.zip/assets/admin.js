let token=null, timer=null, submitted=false;
const $=id=>document.getElementById(id);
async function createSession(){
  clearInterval(timer); submitted=false; $('printBtn').disabled=true; $('copyBtn').disabled=true;
  $('resume').innerHTML='<div class="empty">Waiting for phone submission…</div>';
  $('status').textContent='Creating QR…';
  const r=await fetch('api/create.php',{method:'POST'}); const j=await r.json();
  if(!j.ok){$('status').textContent=j.error;return}
  token=j.token;
  const url=location.origin+location.pathname.replace(/\/[^\/]*$/,'/')+'form.php?token='+token;
  $('qr').innerHTML=''; new QRCode($('qr'),{text:url,width:240,height:240});
  $('sessionUrl').textContent=url; $('copyBtn').disabled=false; $('status').textContent='Waiting for phone…';
  timer=setInterval(checkSession,1500); checkSession();
}
async function checkSession(){
  if(!token)return;
  try{
    const r=await fetch('api/get.php?token='+token+'&_='+Date.now()); const j=await r.json();
    if(!j.ok)return;
    $('status').textContent=j.resume.status==='submitted'?'✓ Resume received':'Waiting for phone…';
    if(j.resume.status==='submitted' && !submitted){submitted=true; renderResume(j.resume); $('printBtn').disabled=false; $('received').textContent='Resume received successfully';}
  }catch(e){}
}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function listItems(arr,type){
 return (arr||[]).map(x=>{
  if(type==='edu')return `<div class="item"><b>${esc(x.degree)}</b> <span>${esc(x.year)}</span><p>${esc(x.institute)}${x.result?' — '+esc(x.result):''}</p></div>`;
  if(type==='exp')return `<div class="item"><b>${esc(x.role)}</b> <span>${esc(x.duration)}</span><p>${esc(x.company)}${x.description?' — '+esc(x.description):''}</p></div>`;
  if(type==='project')return `<div class="item"><b>${esc(x.name)}</b> <span>${esc(x.tech)}</span><p>${esc(x.description)}</p></div>`;
  return `<div class="item"><b>${esc(x.name)}</b></div>`;
 }).join('');
}
function section(title,body){return body?`<div class="rsection"><h3>${title}</h3>${body}</div>`:''}
function renderResume(r){
 const d=r.data||{};
 const photo=r.photo?`<img class="photo" src="${esc(r.photo)}">`:'';
 $('resume').innerHTML=`<div class="resume-head">${photo}<div><div class="rname">${esc(d.name)}</div><div class="rtitle">${esc(d.jobTitle)}</div><div class="contact">${[d.phone,d.email,d.address].filter(Boolean).map(esc).join(' &nbsp;•&nbsp; ')}</div></div></div>
 ${section('Career Objective',d.objective?`<p class="item">${esc(d.objective)}</p>`:'')}
 ${section('Education',listItems(d.education,'edu'))}
 ${section('Experience',listItems(d.experience,'exp'))}
 ${section('Skills',`<div class="skills">${(d.skills||[]).map(s=>`<span class="skill">${esc(s)}</span>`).join('')}</div>`)}
 ${section('Projects',listItems(d.projects,'project'))}
 ${section('Certifications',listItems(d.certifications,'cert'))}
 ${section('Languages',d.languages?`<p class="item">${esc(d.languages)}</p>`:'')}`;
}
$('newBtn').onclick=createSession;
$('copyBtn').onclick=()=>navigator.clipboard.writeText($('sessionUrl').textContent);
$('printBtn').onclick=async()=>{window.print(); await fetch('api/mark_printed.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token})});};
$('clearBtn').onclick=()=>{token=null;submitted=false;clearInterval(timer);$('qr').innerHTML='<div class="qr-placeholder">Click “New Resume”</div>';$('sessionUrl').textContent='';$('status').textContent='No active session';$('resume').innerHTML='<div class="empty">Your submitted resume will appear here.</div>';};
