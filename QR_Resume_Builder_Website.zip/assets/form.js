const token=document.getElementById('token').value, form=document.getElementById('resumeForm'), msg=document.getElementById('msg');
function addBox(parent, fields){
 const wrap=document.createElement('div'); wrap.className='repeat';
 const x=document.createElement('button'); x.type='button'; x.className='remove'; x.textContent='Remove'; x.onclick=()=>wrap.remove(); wrap.appendChild(x);
 fields.forEach(f=>{const l=document.createElement('label');l.innerHTML=esc(f.label)+`<input data-key="${esc(f.key)}" placeholder="${esc(f.ph||'')}">`;wrap.appendChild(l)});
 document.getElementById(parent).appendChild(wrap);
}
function esc(s){return String(s).replace(/"/g,'&quot;').replace(/</g,'&lt;')}
function addEducation(){addBox('education',[{key:'degree',label:'Qualification / Degree',ph:'B.A., B.Tech, Class 12'},{key:'institute',label:'School / College',ph:'Institution name'},{key:'year',label:'Year',ph:'2026'},{key:'result',label:'Result / Percentage',ph:'82%'}])}
function addExperience(){addBox('experience',[{key:'role',label:'Job Role',ph:'Teacher'},{key:'company',label:'Company / Institution',ph:'ABC Coaching Centre'},{key:'duration',label:'Duration',ph:'2024–2026'},{key:'description',label:'Work Description',ph:'Responsibilities and achievements'}])}
function addProject(){addBox('projects',[{key:'name',label:'Project Name',ph:'Student Management System'},{key:'tech',label:'Technology',ph:'Python, MySQL'},{key:'description',label:'Description',ph:'Brief project description'}])}
function addCertification(){addBox('certifications',[{key:'name',label:'Certification',ph:'Certificate name'}])}
function addSkill(){const wrap=document.createElement('div');wrap.className='repeat';wrap.innerHTML='<button type="button" class="remove">Remove</button><label>Skill<input data-key="skill" placeholder="Communication"></label>';wrap.querySelector('.remove').onclick=()=>wrap.remove();document.getElementById('skills').appendChild(wrap)}
addEducation(); addExperience(); addSkill();

function collect(parent, keyMap){
 return [...document.getElementById(parent).querySelectorAll('.repeat')].map(w=>{
  const o={}; w.querySelectorAll('[data-key]').forEach(i=>o[i.dataset.key]=i.value.trim()); return o;
 }).filter(o=>Object.values(o).some(Boolean));
}
function collectSkills(){return [...document.querySelectorAll('#skills [data-key="skill"]')].map(x=>x.value.trim()).filter(Boolean)}

function fileToData(file){return new Promise((resolve,reject)=>{if(!file)return resolve(null);const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)})}
form.addEventListener('submit',async e=>{
 e.preventDefault(); msg.className='message';msg.textContent='Submitting…';
 const data={}; ['name','jobTitle','phone','email','address','objective','languages'].forEach(id=>data[id]=document.getElementById(id).value.trim());
 data.education=collect('education'); data.experience=collect('experience'); data.projects=collect('projects'); data.certifications=collect('certifications'); data.skills=collectSkills();
 const photo=await fileToData(document.getElementById('photo').files[0]);
 try{
  const r=await fetch('api/submit.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,data,photo})});
  const j=await r.json(); if(!j.ok)throw new Error(j.error||'Submission failed');
  form.innerHTML='<div style="text-align:center;padding:45px 10px"><h2>✓ Resume Submitted</h2><p>Your details have been sent to the computer. You can close this page now.</p></div>';
 }catch(err){msg.className='message error';msg.textContent=err.message}
});
