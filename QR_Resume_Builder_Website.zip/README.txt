QR RESUME BUILDER — ONLINE WEBSITE

WHAT THIS PACKAGE CONTAINS
- PHP + MySQL website
- PC/Admin dashboard with QR generator
- Mobile resume form
- Live submission polling
- A4 resume preview
- Print / Save as PDF
- Photo upload
- Education, experience, skills, projects, certifications and languages

REQUIREMENTS
- PHP 8+ with PDO MySQL enabled
- MySQL 5.7+/MariaDB
- Any normal PHP hosting (cPanel hosting works well)

INSTALLATION
1. Create a MySQL database and user in your hosting control panel.
2. Import db.sql using phpMyAdmin.
3. Edit config.php with your database host/name/user/password.
4. Upload all files/folders to public_html (or your desired site folder).
5. Open your domain in a browser.
6. Click "New Resume" on the PC.
7. Scan the QR from a phone and submit the form.
8. The PC dashboard receives the resume. Click Print.

IMPORTANT
- The mobile QR link uses the same domain as the PC dashboard.
- For production, use HTTPS.
- For privacy, add authentication to the admin dashboard before using it with real customer data.
- QR sessions expire after the number of minutes defined by SESSION_MINUTES in config.php.
- The CDN QR library is loaded from jsDelivr. If you want a fully offline/self-hosted QR library, replace it with a local copy.
