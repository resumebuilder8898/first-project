<?php
// Database settings
define('DB_HOST', 'localhost');
define('DB_NAME', 'resume_builder');
define('DB_USER', 'root');
define('DB_PASS', '');

// Change this in production.
define('APP_NAME', 'QR Resume Builder');
define('SESSION_MINUTES', 60);
?>
