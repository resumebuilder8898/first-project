<?php
$token = preg_replace('/[^a-f0-9]/','', $_GET['token'] ?? '');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fill Resume</title><link rel="stylesheet" href="assets/style.css">
</head>
<body class="mobile-body">
<div class="mobile-wrap">
<div class="mobile-header"><h1>Build Your Resume</h1><p>Fill your details below. Your resume will be generated on the computer.</p></div>
<form id="resumeForm" class="form-card">
<input type="hidden" id="token" value="<?= htmlspecialchars($token) ?>">
<label>Full Name *<input id="name" required placeholder="e.g. Rahul Kumar"></label>
<label>Job Title / Profession<input id="jobTitle" placeholder="e.g. Teacher"></label>
<label>Phone<input id="phone" type="tel" placeholder="9876543210"></label>
<label>Email<input id="email" type="email" placeholder="you@example.com"></label>
<label>Address<textarea id="address" rows="2" placeholder="City, State"></textarea></label>
<label>Profile Photo<input id="photo" type="file" accept="image/*"></label>
<label>Career Objective<textarea id="objective" rows="4" placeholder="Write a short career objective..."></textarea></label>

<div class="section-title">Education</div>
<div id="education"></div><button type="button" class="btn small" onclick="addEducation()">＋ Add Education</button>

<div class="section-title">Experience</div>
<div id="experience"></div><button type="button" class="btn small" onclick="addExperience()">＋ Add Experience</button>

<div class="section-title">Skills</div>
<div id="skills"></div><button type="button" class="btn small" onclick="addSkill()">＋ Add Skill</button>

<div class="section-title">Projects</div>
<div id="projects"></div><button type="button" class="btn small" onclick="addProject()">＋ Add Project</button>

<div class="section-title">Certifications</div>
<div id="certifications"></div><button type="button" class="btn small" onclick="addCertification()">＋ Add Certification</button>

<label>Languages<textarea id="languages" rows="2" placeholder="Hindi, English"></textarea></label>
<button class="btn primary submit-btn" type="submit">Submit Resume</button>
<div id="msg" class="message"></div>
</form>
</div>
<script src="assets/form.js"></script>
</body></html>
